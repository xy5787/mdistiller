"""
Step 3: Pixel Sweep — generate synthetic dataset by exhaustively sweeping salient pixels.

For each class:
  1. Pick a representative seed image (class prototype from training set)
  2. For each of the top-k salient pixels, sweep values 0→255
  3. Record teacher's soft output for each perturbed image

Output: outputs/sweep_dataset.pt

Usage:
    cd mdistiller
    python tools/probe_sweep/step3_pixel_sweep.py
    python tools/probe_sweep/step3_pixel_sweep.py --top_k 20 --num_values 256 --seed_mode mean
"""
import os
import sys
import argparse
import torch

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
sys.path.insert(0, ROOT)

from mdistiller.models.mnist import TeacherCNN
from mdistiller.dataset.mnist import get_mnist_dataloaders
from mdistiller.distillers.ManifoldProbe import ManifoldProbe


def get_seed_images(dataloader, num_classes=10, mode="mean"):
    """
    Get one seed image per class.

    mode="mean":   average all training images of that class (class prototype)
    mode="first":  just take the first image of that class
    mode="random": random noise (for data-free baseline)
    """
    if mode == "random":
        seeds = {}
        for c in range(num_classes):
            seeds[c] = torch.rand(1, 1, 28, 28)
        return seeds

    # Accumulate per class
    class_sum = {c: torch.zeros(1, 1, 28, 28) for c in range(num_classes)}
    class_count = {c: 0 for c in range(num_classes)}
    class_first = {}

    for images, labels in dataloader:
        for i in range(len(labels)):
            c = labels[i].item()
            if mode == "first" and c in class_first:
                continue
            if mode == "first":
                class_first[c] = images[i:i+1]
            else:
                class_sum[c] += images[i:i+1]
                class_count[c] += 1

        if mode == "first" and len(class_first) == num_classes:
            break

    if mode == "first":
        return class_first
    else:  # mean
        return {c: class_sum[c] / max(class_count[c], 1) for c in range(num_classes)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--teacher_ckpt", type=str, default="checkpoints/teacher_mnist.pth")
    parser.add_argument("--saliency_path", type=str, default="outputs/saliency/all_classes.pt")
    parser.add_argument("--top_k", type=int, default=20)
    parser.add_argument("--num_values", type=int, default=256,
                        help="Number of sweep values per pixel (256 = full 8-bit)")
    parser.add_argument("--seed_mode", type=str, default="mean",
                        choices=["mean", "first", "random"],
                        help="How to generate seed images")
    parser.add_argument("--save_path", type=str, default="outputs/sweep_dataset.pt")
    parser.add_argument("--data_root", type=str, default="./data")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Load teacher
    teacher = TeacherCNN(num_classes=10)
    ckpt = torch.load(args.teacher_ckpt, map_location="cpu", weights_only=False)
    teacher.load_state_dict(ckpt["model"])
    print(f"Loaded teacher (val_acc: {ckpt['val_acc']:.4f})")

    probe = ManifoldProbe(teacher, device=device)

    # Load saliency data
    sal_data = torch.load(args.saliency_path, weights_only=False)
    all_pixels = sal_data["pixels"]  # dict: class -> list of (r, c)

    # Get seed images
    if args.seed_mode == "random":
        print("Using RANDOM seed images (data-free mode)")
        seeds = get_seed_images(None, mode="random")
    else:
        print(f"Using {args.seed_mode} seed images from training set")
        train_loader, _, _ = get_mnist_dataloaders(batch_size=256, data_root=args.data_root)
        seeds = get_seed_images(train_loader, mode=args.seed_mode)

    # ── Sweep ──
    all_images = []
    all_soft = []
    all_hard = []

    total_pairs = 10 * args.top_k * args.num_values
    print(f"\nTotal sweep: 10 classes × {args.top_k} pixels × {args.num_values} values = {total_pairs:,} pairs")

    for c in range(10):
        pixels = all_pixels[c][:args.top_k]
        seed = seeds[c]  # [1, 1, 28, 28]

        print(f"\nClass {c}: sweeping {len(pixels)} pixels × {args.num_values} values...")
        result = probe.pixel_sweep(seed, pixels, num_values=args.num_values)

        all_images.append(result["images"])
        all_soft.append(result["soft_labels"])
        all_hard.append(result["hard_labels"])

    # Concatenate
    dataset = {
        "images": torch.cat(all_images, dim=0),
        "soft_labels": torch.cat(all_soft, dim=0),
        "hard_labels": torch.cat(all_hard, dim=0),
        "metadata": {
            "top_k": args.top_k,
            "num_values": args.num_values,
            "seed_mode": args.seed_mode,
            "total_samples": total_pairs,
        }
    }

    os.makedirs(os.path.dirname(args.save_path), exist_ok=True)
    torch.save(dataset, args.save_path)

    print(f"\n{'='*50}")
    print(f"Synthetic dataset saved: {args.save_path}")
    print(f"  Shape: {dataset['images'].shape}")
    print(f"  Hard label distribution: {torch.bincount(dataset['hard_labels'], minlength=10).tolist()}")
    print(f"  File size: {os.path.getsize(args.save_path) / 1e6:.1f} MB")


if __name__ == "__main__":
    main()
