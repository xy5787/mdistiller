"""
ManifoldProbe: Data-Free KD via gradient saliency + pixel sweep.

Core idea:
1. Use teacher's gradient to find which input pixels most affect each class output
2. Sweep those pixels exhaustively (0~255) to build synthetic dataset
3. Distill teacher's soft labels on this synthetic data to student

This module contains:
- Saliency computation (gradient-based attribution)
- Salient pixel selection (top-k per class)
- Pixel sweep (independent exhaustive search per pixel)
- ManifoldProbeKD distiller (standard KD on synthetic data)
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm


# ============================================================
# Part 1: Saliency & Sweep (used in data generation phase)
# ============================================================

class ManifoldProbe:
    """
    Probes a teacher network to find salient pixels and sweep them.
    This is NOT an nn.Module -- it's a utility class for data generation.
    """

    def __init__(self, teacher, device="cuda"):
        self.teacher = teacher.to(device).eval()
        self.device = device

    @torch.enable_grad()
    def get_saliency(self, x, target_class):
        """
        Compute gradient-based saliency: |d(logit[target_class]) / d(x)|

        Args:
            x: input image [1, 1, 28, 28], values in [0, 1]
            target_class: which output neuron to trace back from (0~9)

        Returns:
            saliency_map: [28, 28] tensor of absolute gradient magnitudes
        """
        x = x.clone().detach().to(self.device).requires_grad_(True)
        logits, _ = self.teacher(x)
        logits[0, target_class].backward()
        saliency = x.grad.abs().squeeze()  # [28, 28]
        return saliency.detach().cpu()

    def get_class_saliency(self, dataloader, target_class, max_samples=100):
        """
        Aggregate saliency maps across multiple samples of a given class.
        Returns the mean saliency map for that class.

        Args:
            dataloader: MNIST dataloader
            target_class: digit class (0~9)
            max_samples: how many seed images to average over

        Returns:
            mean_saliency: [28, 28] averaged saliency map
        """
        saliency_sum = torch.zeros(28, 28)
        count = 0

        for images, labels in dataloader:
            # Filter only samples of target class
            mask = labels == target_class
            if mask.sum() == 0:
                continue

            class_images = images[mask]
            for i in range(min(len(class_images), max_samples - count)):
                img = class_images[i:i+1]  # [1, 1, 28, 28]
                sal = self.get_saliency(img, target_class)
                saliency_sum += sal
                count += 1
                if count >= max_samples:
                    break
            if count >= max_samples:
                break

        mean_saliency = saliency_sum / max(count, 1)
        return mean_saliency

    def select_salient_pixels(self, saliency_map, top_k=20):
        """
        Pick the top-k most salient pixel locations.

        Args:
            saliency_map: [28, 28] saliency values
            top_k: number of pixels to select

        Returns:
            list of (row, col) tuples, sorted by descending saliency
        """
        flat = saliency_map.flatten()
        _, indices = flat.topk(top_k)
        rows = indices // 28
        cols = indices % 28
        return list(zip(rows.tolist(), cols.tolist()))

    def pixel_sweep(self, base_image, salient_pixels, num_values=256):
        """
        Independently sweep each salient pixel through [0, 1] (quantized to num_values).
        For each sweep, record the full image + teacher's soft output.

        Args:
            base_image: [1, 1, 28, 28] seed image
            salient_pixels: list of (row, col) from select_salient_pixels
            num_values: number of values to try per pixel (default: 256 for 8-bit)

        Returns:
            dict with keys: images [N, 1, 28, 28], soft_labels [N, 10], hard_labels [N]
            where N = len(salient_pixels) * num_values
        """
        images = []
        soft_labels = []
        hard_labels = []

        values = torch.linspace(0, 1, num_values)

        self.teacher.eval()
        with torch.no_grad():
            for (r, c) in tqdm(salient_pixels, desc="Sweeping pixels"):
                for val in values:
                    img = base_image.clone()
                    img[0, 0, r, c] = val.item()

                    logits, _ = self.teacher(img.to(self.device))
                    prob = F.softmax(logits, dim=1)

                    images.append(img.squeeze(0).cpu())       # [1, 28, 28]
                    soft_labels.append(prob.squeeze(0).cpu())  # [10]
                    hard_labels.append(prob.argmax().item())

        return {
            "images": torch.stack(images),          # [N, 1, 28, 28]
            "soft_labels": torch.stack(soft_labels), # [N, 10]
            "hard_labels": torch.tensor(hard_labels), # [N]
        }


# ============================================================
# Part 2: Distiller (used in training phase)
# ============================================================

def manifold_kd_loss(logits_student, soft_labels, temperature):
    """
    KL divergence between student output and teacher's pre-computed soft labels.
    Same as standard KD loss but teacher side is already a probability distribution.
    """
    log_pred_student = F.log_softmax(logits_student / temperature, dim=1)
    # soft_labels are already probabilities; sharpen/soften with temperature
    soft_teacher = torch.pow(soft_labels, 1.0 / temperature)
    soft_teacher = soft_teacher / soft_teacher.sum(dim=1, keepdim=True)
    loss = F.kl_div(log_pred_student, soft_teacher, reduction="batchmean")
    loss *= temperature ** 2
    return loss


class ManifoldProbeKD(nn.Module):
    """
    Distiller for ManifoldProbe: trains student on synthetic sweep data.

    Unlike standard mdistiller Distiller which takes (image, target) from a real dataset,
    this takes (image, soft_label, hard_label) from SyntheticSweepDataset.

    We keep this as a standalone nn.Module (not inheriting from _base.Distiller)
    because the training loop differs from standard KD.
    """

    def __init__(self, student, temperature=4.0, ce_weight=0.1, kd_weight=0.9):
        super().__init__()
        self.student = student
        self.temperature = temperature
        self.ce_weight = ce_weight
        self.kd_weight = kd_weight

    def forward(self, image, soft_label, hard_label):
        """
        Args:
            image: [B, 1, 28, 28] synthetic images
            soft_label: [B, 10] teacher's soft predictions
            hard_label: [B] teacher's hard predictions

        Returns:
            logits_student, losses_dict
        """
        logits_student, feats = self.student(image)

        loss_ce = self.ce_weight * F.cross_entropy(logits_student, hard_label)
        loss_kd = self.kd_weight * manifold_kd_loss(
            logits_student, soft_label, self.temperature
        )

        losses_dict = {
            "loss_ce": loss_ce,
            "loss_kd": loss_kd,
        }
        return logits_student, losses_dict
